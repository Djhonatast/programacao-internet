let inpnum1 = document.querySelector ("#inpnum1")
let inpnum2 = document.querySelector ("#inpnum2")
let btcalcular = document.querySelector ("#btcalcular")
let h3soma = document.querySelector ("#h3soma")
let h3subtrair = document.querySelector ("#h3subtrair")
let h3multiplicar = document.querySelector ("#h3multiplicar")
let h3dividir = document.querySelector ("#h3dividir")

function operar(){
    let num1 = Number(inpnum1.value)
    let num2 = Number(inpnum2.value)

    h3soma.textContent = ( num1 + num2)
    h3subtrair.textContent = (num1 - num2)
    h3multiplicar.textContent = (num1 * num2)
    h3dividir.textContent = (num1 / num2)
}

btcalcular.onclick = function (){
    operar()
}