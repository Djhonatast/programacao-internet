let inpsaldo = document.querySelector ("#inpsaldo")
let btimprimir = document.querySelector ("#btimprimir")
let h2exibir = document.querySelector ("#h2exibir")
let umporcent = document.querySelector ("#umporcent")
let cemporcent = document.querySelector ("#cemporcent")

function porcentagem (){
    let saldo = Number(inpsaldo.value)
    let imprimir = Number(btimprimir.value)
    h2exibir.textContent = ( (saldo/100) + saldo )

}

btimprimir.onclick = function(){
porcentagem();
}




