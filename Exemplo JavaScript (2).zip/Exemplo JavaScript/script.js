let Titulo = document.querySelector("#Titulo");
let CampoTexto = document.querySelector("#CampoTexto");
let btTrocarTexto = document.querySelector("#btTrocarTexto");
function alterartexto(){
    //Retirando o valor digitado no input
    //e jogando na variável
let textoDigitado = CampoTexto.value;
//atribuindo o elemento titulo o texto que foi digitado no input
Titulo.textContent = textoDigitado;

}
//atribuindo uma ação de clicar no botão

btTrocarTexto.onclick = function(){
    alterartexto();
}