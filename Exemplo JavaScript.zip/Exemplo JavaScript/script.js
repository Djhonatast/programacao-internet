let Titulo = document.querySelector("#Titulo");
let CampoTexto = document.querySelector("#CampoTexto");
let btTrocarTexto = document.querySelector("#btTrocarTexto");