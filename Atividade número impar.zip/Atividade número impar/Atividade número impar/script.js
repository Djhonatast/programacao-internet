let inpnum1 = document.querySelector("#inpnum1")
let btverify = document.querySelector("#btverify")
let h3result = document.querySelector("#h3result")

function impar(){
    let num1 = Number(inpnum1.Value)
}