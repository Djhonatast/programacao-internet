let valorkg = document.querySelector ("#valorkg");
let quantconsumida = document.querySelector ("#quantconsumida");
let valpagar = document.querySelector ("#valpagar");
let btcalcular = document.querySelector("#btcalcular")

function multiplicar(){
    let valkg = Number(valorkg.value);
    let quantcons = Number(quantconsumida.value);
valpagar.textContent = (valkg * quantcons)
}

btcalcular.onclick = function(){
 multiplicar();
}

