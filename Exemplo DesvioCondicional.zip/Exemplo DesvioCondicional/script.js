let inpn1 = document.querySelector("#inpn1")
let inpn2 = document.querySelector("#inpn2")
let btcalcular = document.querySelector("#btcalcular")
let h3result = document.querySelector("#h3result")

function media (){
let n1 = Number(inpn1.value)
let n2 = Number(inpn2.value)
let media = ((n1 + n2) / 2)
//Aprovado: media 6.0 ou maior
//Reprovado: media menor que 6.0
if(media>=6.0){
    h3result.textContent = "Parabens voce esta aprovado!!"
}
else
{
    h3result.textContent = "Reprovado, se esforce ano que vem"
}
}

btcalcular.onclick = function(){
    media()
}