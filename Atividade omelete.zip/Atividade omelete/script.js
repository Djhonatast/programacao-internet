let inpnumpessoas = document.querySelector ("#inpnumpessoas")
let btingr = document.querySelector ("#btingr")
let h3ovos = document.querySelector ("#h3ovos")
let h3queijo = document.querySelector ("#h3queijo")

function ingredientes(){
    let numpessoas = Number(inpnumpessoas.value)
    h3ovos.textContent = ( (numpessoas * 2)  )
    h3queijo.textContent = ( (numpessoas * 50))
}

btingr.onclick = function (){
ingredientes()
}