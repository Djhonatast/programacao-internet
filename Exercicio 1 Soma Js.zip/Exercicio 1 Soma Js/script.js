
let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let btrealizarsoma = document.querySelector("#btrealizarsoma");
let h3exibirsoma = document.querySelector("#h3exibirsoma");

function somar(){
let num1 = Number(numero1.value);
let num2 = Number(numero2.value);
h3exibirsoma.textContent = (num1 + num2);

}

btrealizarsoma.onclick = function(){
    somar();

}

