let numero1 = document.querySelector ("#numero1")
let numero2 = document.querySelector ("#numero2")
let numero3 = document.querySelector ("#numero3")
let medarit = document.querySelector ("#medarit")
let medpond = document.querySelector ("#medpond")
let somamed = document.querySelector ("#somamed")
let meddamed = document.querySelector ("#meddamed")
let btcalcular = document.querySelector ("#btcalcular")

function aritmetica(){
numero1 = Number(numero1.value);
numero2 = Number(numero1.value);
numero3 = Number(numero1.value);
medarit.textContent = ( );
}

function ponderada(){
    numero1 = Number(numero1.value);
    numero2 = Number(numero1.value);
    numero3 = Number(numero1.value);
    medpond.textContent = ( );
}

function soma(){

    somamed.textContent = ( );
}

function mediamedia(){
meddamed.textContent = ();
}