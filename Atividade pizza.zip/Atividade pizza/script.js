let inpsab1 = document.querySelector ("#inpsab1")
let inpsab2 = document.querySelector ("#inpsab2")
let inpsab3 = document.querySelector ("#inpsab3")
let inpsab4 = document.querySelector ("#inpsab4")
let inprefri = document.querySelector ("#inprefri")
let btpedir = document.querySelector ("#btpedir")
let h3sab1 = document.querySelector ("#h3sab1")
let h3sab2 = document.querySelector ("#h3sab2")
let h3sab3 = document.querySelector ("#h3sab3")
let h3sab4 = document.querySelector ("#h3sab4")
let h3refri = document.querySelector ("#h3refri")
let h3valor = document.querySelector ("#h3valor")




function pizza(){
    let refri = Number(inprefri.value)
    let sab1 = (inpsab1)
    let sab2 = (inpsab2)
    let sab3 = (inpsab3)
    let sab4 = (h3sab4)
    h3sab1.textContent(sab1)
    h3sab2.textContent(sab2)
    h3sab3.textContent(sab3)
    h3sab4.textContent(sab4)
    h3refri.textContent(refri)
    h3valor.textContent((12 * 4) + (refri * 7))
}

    btpedir.onclick = function (){
        pizza()

    }

    