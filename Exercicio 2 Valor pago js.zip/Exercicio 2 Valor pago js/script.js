let inpvalorrecebido = document.querySelector("#inpvalorrecebido");
let btpagar = document.querySelector("#btpagar")
let h3troco = document.querySelector("#h3troco")
let valorproduto = ( "#valorproduto")

function subtrair(){
    let val1 = Number(inpvalorrecebido.value);
    let val2 =Number(valorproduto.value);
    val2 = 29;
    h3troco.textContent = ( val1 - val2);
}

btpagar.onclick = function(){
subtrair();
}