let inpvalor = document.querySelector ( "#inpvalor")
let inpvalorrecebido = document.querySelector("#inpvalorrecebido");
let btpagar = document.querySelector("#btpagar")
let h3troco = document.querySelector("#h3troco")


function subtrair(){
    let val1 = Number(inpvalor.value);
    let val2 =Number(inpvalorrecebido.value);
 
    h3troco.textContent = ( val2 - val1 );
}

btpagar.onclick = function(){
subtrair();
}