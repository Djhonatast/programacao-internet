 let cotacaodolar = document.querySelector ("#cotacaodolar")
 let btcalcular = document.querySelector ("#btcalcular")
 let h3umpor = document.querySelector ("#h3umpor")
 let h3doispor = document.querySelector ("#h3doispor")
 let h3cincopor = document.querySelector ("#h3cincopor")
 let h3dezpor = document.querySelector ("#h3dezpor")

 function cotar(){
    let cotacao = Number(cotacaodolar.value)

    h3umpor.textContent = ((cotacao/100) + cotacao)
    h3doispor.textContent = ((cotacao/50) + cotacao)
    h3cincopor.textContent = ((cotacao/20) + cotacao)
    h3dezpor.textContent = ((cotacao/10) + cotacao)

 }

 btcalcular.onclick = function(){
    cotar()
 }