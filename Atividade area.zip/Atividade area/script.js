let inpnum1 = document.querySelector ("#inpnum1");
let inpnum2 = document.querySelector ("#inpnum2");
let btcalcular = document.querySelector ("#btcalcular");
let h3result = document.querySelector ("#h3result");

function area (){
let num1 = Number(inpnum1.value);
let num2 = Number(inpnum2.value);
h3result.textContent = ((num1 * 2) * (num2 * 2)) + " m2";
};

btcalcular.onclick = function(){
    area();
};